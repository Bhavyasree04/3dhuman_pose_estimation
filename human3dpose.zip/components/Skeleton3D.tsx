
import React, { useEffect, useRef } from 'react';
import * as THREE from 'three';

interface Skeleton3DProps {
  landmarks: any; // results.poseWorldLandmarks
}

export const Skeleton3D: React.FC<Skeleton3DProps> = ({ landmarks }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const jointsRef = useRef<THREE.Group[]>([]);
  const bonesRef = useRef<THREE.Line[]>([]);

  // Connectivity for skeleton (standard MediaPipe pairs)
  const POSE_CONNECTIONS = [
    [11, 12], [11, 13], [13, 15], [12, 14], [14, 16], // Upper body
    [11, 23], [12, 24], [23, 24], // Torso
    [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [27, 31], [28, 32] // Lower body
  ];

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020617);
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, containerRef.current.clientWidth / containerRef.current.clientHeight, 0.1, 1000);
    camera.position.set(0, 0, 3);
    cameraRef.current = camera;

    const renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    containerRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);
    const pointLight = new THREE.PointLight(0x3b82f6, 1);
    pointLight.position.set(2, 2, 2);
    scene.add(pointLight);

    // Grid for perspective
    const grid = new THREE.GridHelper(5, 10, 0x1e293b, 0x0f172a);
    grid.position.y = -1;
    scene.add(grid);

    // Initialize 33 Joints (spheres)
    const jointGeometry = new THREE.SphereGeometry(0.02, 16, 16);
    const jointMaterial = new THREE.MeshPhongMaterial({ color: 0xffffff });
    const joints: THREE.Mesh[] = [];
    for (let i = 0; i < 33; i++) {
      const mesh = new THREE.Mesh(jointGeometry, jointMaterial);
      mesh.visible = false;
      scene.add(mesh);
      joints[i] = mesh;
    }
    // @ts-ignore
    jointsRef.current = joints;

    // Initialize Bones (lines)
    const boneMaterial = new THREE.LineBasicMaterial({ color: 0x3b82f6, linewidth: 2 });
    const bones: THREE.Line[] = [];
    POSE_CONNECTIONS.forEach(() => {
      const geometry = new THREE.BufferGeometry();
      geometry.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0, 0], 3));
      const line = new THREE.Line(geometry, boneMaterial);
      line.visible = false;
      scene.add(line);
      bones.push(line);
    });
    bonesRef.current = bones;

    const animate = () => {
      if (!rendererRef.current || !sceneRef.current || !cameraRef.current) return;
      requestAnimationFrame(animate);
      rendererRef.current.render(sceneRef.current, cameraRef.current);
    };
    animate();

    const handleResize = () => {
      if (!containerRef.current || !cameraRef.current || !rendererRef.current) return;
      cameraRef.current.aspect = containerRef.current.clientWidth / containerRef.current.clientHeight;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(containerRef.current.clientWidth, containerRef.current.clientHeight);
    };
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (containerRef.current) containerRef.current.removeChild(renderer.domElement);
    };
  }, []);

  // Update positions based on landmarks
  useEffect(() => {
    if (!landmarks || jointsRef.current.length === 0) return;

    landmarks.forEach((lm: any, i: number) => {
      const joint = jointsRef.current[i];
      if (joint) {
        // MediaPipe Y is inverted for Three.js
        // We scale by -1 for Y to stand them up
        joint.position.set(-lm.x, -lm.y, -lm.z);
        // @ts-ignore
        joint.visible = lm.visibility > 0.5;
      }
    });

    POSE_CONNECTIONS.forEach((pair, i) => {
      const bone = bonesRef.current[i];
      const start = landmarks[pair[0]];
      const end = landmarks[pair[1]];

      if (bone && start && end && start.visibility > 0.5 && end.visibility > 0.5) {
        const positions = bone.geometry.attributes.position.array as Float32Array;
        positions[0] = -start.x;
        positions[1] = -start.y;
        positions[2] = -start.z;
        positions[3] = -end.x;
        positions[4] = -end.y;
        positions[5] = -end.z;
        bone.geometry.attributes.position.needsUpdate = true;
        bone.visible = true;
      } else if (bone) {
        bone.visible = false;
      }
    });
  }, [landmarks]);

  return (
    <div 
      ref={containerRef} 
      className="w-full h-full rounded-[2rem] overflow-hidden border border-slate-800 shadow-inner relative"
    >
      <div className="absolute top-4 left-4 z-10 bg-slate-900/50 backdrop-blur px-3 py-1 rounded-full border border-white/10 flex items-center gap-2">
        <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">Kinetic Engine 3.0 (3D View)</span>
      </div>
    </div>
  );
};
